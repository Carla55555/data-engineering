exercise 1.2: Check the logs for something strange. Try to know where those messages
come from. No need to solve it, only get the origin.

The example of duplicate messages is set up with the song in this way.

In the scraper.log, the strange thing I've noticed is that when a song has already been downloaded, it sends two practically identical messages. The first is this: File ./files\songs\abel_zavala\de_tal_manera.txt already exists. Skipping download. This message comes from the get_song_lyrics function, which we call in the get_songs function.

The second message is this: File already exists, skipping: ./files\songs\abel_zavala\de_tal_manera.txt. This is called later in the get_songs function. In this way, we get the same message about the same song twice if it tells us that the song has already been downloaded.


exercise 1.5: Propose any change to make the code cleaner, clearer and better.

One improvement I would make to the project is to avoid using global variables in recursive functions, especially in the validator. In the original code, the list_files_recursive function appended results to a global list. This works, but it makes the behavior less predictable and can lead to duplicate results if the function is called more than once. The improved version has the function manage its own list of files and return it without relying on anything external. This makes the code cleaner, easier to understand, and more secure against future changes.

Another improvement would be to unify path construction by properly using the functions and libraries that Python offers, instead of handling paths through string concatenation or replace. If methods like os.path.join, os.path.dirname, or os.path.relpath are used throughout the project, the code becomes clearer, more maintainable, and cross-platform compatible. Furthermore, it reduces the likelihood of errors when creating folders and files and ensures that the directory structure always follows a single logic.